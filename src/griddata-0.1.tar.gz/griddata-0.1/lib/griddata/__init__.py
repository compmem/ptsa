from griddata import griddata, __doc__, __version__
