from matplotlib.numerix.random_array import uniform
from griddata import griddata
import pylab as p

npts = int(raw_input('enter # of random points to plot:'))
x = uniform(-2,2,npts);  y = uniform(-2,2,npts)
z = x*p.exp(-x**2-y**2)

# x, y, and z are now vectors containing nonuniformly sampled data.
# Define a regular grid and grid data to it.
nx = 51; ny = 41
xi, yi = p.meshgrid(p.linspace(-2,2,nx),p.linspace(-2,2,ny))
# masked=True mean no extrapolation, output is masked array.
zi = griddata(x,y,z,xi,yi,masked=True)

print 'min/max = ',min(zi.compressed()),max(zi.compressed())

ax = p.axes([0.1,0.1,0.75,0.75])
# Contour the gridded data, plotting dots at the nonuniform data points.
CS = p.contour(xi,yi,zi,15,linewidths=0.5,colors=['k'])
CS = p.contourf(xi,yi,zi,15,cmap=p.cm.jet)
cax = p.axes([0.875, 0.1, 0.05, 0.75]) # setup colorbar axes
p.colorbar(tickfmt='%4.2f', cax=cax) # draw colorbar
p.axes(ax)  # make the original axes current again
p.scatter(x,y,marker='o',c='b',s=5)
p.xlim(-1.9,1.9)
p.ylim(-1.9,1.9)
p.title('griddata test (%d points)' % npts)
#p.savefig('griddata.png')
p.show()
